﻿using LMSystem.DAO;
using LMSystem.Models.Entities;
using LMSystem.Repositories.Common;

namespace LMSystem.Repositories.Domain
{
    public class BookRepository : BaseRepository<BookEntity>, IBookRepository
    {
        private readonly LMSystemDbContext _dbContext;

        public BookRepository(LMSystemDbContext dbContext):base(dbContext) 
        {
            this._dbContext = dbContext;
        }
    }
}
