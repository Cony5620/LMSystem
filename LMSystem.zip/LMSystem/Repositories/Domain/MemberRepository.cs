﻿using LMSystem.DAO;
using LMSystem.Models.Entities;
using LMSystem.Repositories.Common;

namespace LMSystem.Repositories.Domain
{
    public class MemberRepository: BaseRepository<MemberEntity>, IMemberRepository
    {
        public MemberRepository(LMSystemDbContext dbContext):base(dbContext)
        {
            
        }
    }
}
