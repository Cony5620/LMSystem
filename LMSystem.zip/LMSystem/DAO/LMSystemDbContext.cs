﻿using LMSystem.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace LMSystem.DAO
{
    public class LMSystemDbContext:DbContext
    {
        public LMSystemDbContext(DbContextOptions<LMSystemDbContext>options):base(options) { }
        public DbSet<CategoryEntity> Categories { get; set; }
        public DbSet<AuthorEntity> Authors { get; set; }
        public DbSet<PublisherEntity> Publishers { get; set; }
        public DbSet<MemberEntity> Members { get; set; }
        public DbSet<LibrarianEntity> Librarians { get; set; }
        public DbSet<BookEntity> Books { get; set; }
        public DbSet<IssueBookEntity>IssueBooks { get; set; }    
    }
}
