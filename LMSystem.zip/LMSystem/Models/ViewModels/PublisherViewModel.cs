﻿namespace LMSystem.Models.ViewModels
{
    public class PublisherViewModel
    {
        public string id { get; set; }
        public string Name { get; set; }
        public string Adress { get; set; }
        public string ContactInfo { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
     
    }
}
