﻿using LMSystem.DAO;
using LMSystem.Models.Entities;
using LMSystem.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LMSystem.Controllers
{
    public class IssueBookController : Controller
    {
        private readonly LMSystemDbContext _dbContext;

        public IssueBookController(LMSystemDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IActionResult Entry()
        {
            BindBookdata();
            BindMemberdata();
            return View();
        }

        private void BindMemberdata()
        {
            IList<MemberViewModel> Member = _dbContext.Members.Where(w => !w.IsInActive).Select(s => new MemberViewModel
            {
                id = s.id,
                Name = s.Name,

            }).ToList();
            ViewBag.Member = Member;
        }

        private void BindBookdata()
        {
          IList<BookViewModel> book = _dbContext.Books.Where(w => !w.IsInActive).Select(s =>new BookViewModel
          {
              id=s.id,
               Title=s.Title,
            
          }).ToList();
            ViewBag.Book = book;
        }
        [HttpPost]
        public IActionResult Entry(IssueBookViewModel issueBookViewModel)
        {
            try
            {
                IssueBookEntity issueBookEntity = new IssueBookEntity()

                {
                    id = Guid.NewGuid().ToString(),
                    Bookid = issueBookViewModel.Bookid,
                    Memberid = issueBookViewModel.Memberid,
                    IssueDate = issueBookViewModel.IssueDate,
                    DueDate = issueBookViewModel.DueDate,
                };
                _dbContext.IssueBooks.Add(issueBookEntity);
                _dbContext.SaveChanges();
                ViewData["Info"] = "Successfully save to the system";
                ViewData["status"] = true;
            }
            catch (Exception e)
            {

                ViewData["Info"] = "Errp save to the system" + e.Message;
                ViewData["status"] = false;
            }
            BindBookdata();
            BindMemberdata();
            return View();
      
        }    
    }
}


        
    

